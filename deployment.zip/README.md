<h1 align="center">Hi 👋, I'am Satyanarayana Sure</h1>
<h3 align="center">A DevOps enthusiast from Singapore</h3>

- 🔭 I’m currently working on [DevOps Project using git, github, AWS, linux, Jenkins, SonarQube, Trivy, Ansible ,terraform,and Docker,k8s](https://github.com/praveensirvi1212/DevSecOps-project)

- 🌱 I’m Working as SME and Technical Lead of  **DevOps**

- 💻[Portfolio](https://gitlab.com/uploads/-/system/user/avatar/5442884/avatar.png)

- 📝 I regularly write articles on Medium [https://medium.com/@satyanarayana.sure](https://medium.com/@satyanarayana.sure)

- 💬 Ask me about **git,github,Linux,aws,SonarQube,docker,jenkins,kubernetes**

- 📫 How to reach me **satyanarayana.sure@gmail.com**



curl -L -o download.zip https://api.github.com/repos/satyasure/webserver/zipball/master



curl -L -o download.zip $(curl -s https://api.github.com/repos/satyasure/webserver/releases/latest | grep "browser_download_url.*zip" | cut -d : -f 2,3 | tr -d \")

curl -L -o download.tar.gz $(curl -s https://api.github.com/repos/satyasure/webserver/releases/latest | grep "browser_download_url.*tar.gz" | cut -d : -f 2,3 | tr -d \")
