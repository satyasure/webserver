export const USERS = 'USERS';
export const USERS_LOADING = 'USERS_LOADING'
export const USER_ACTIVE = 'USER_ACTIVE'
export const API_URL= window.location.protocol+"//"+window.location.host;
//export const API_URL= "http://localhost:8080";