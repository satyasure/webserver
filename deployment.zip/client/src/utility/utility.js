export function isNullOrUndefined(obj){
    return obj===null || obj===undefined
}